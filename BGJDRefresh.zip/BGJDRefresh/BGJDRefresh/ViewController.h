//
//  ViewController.h
//  BGJDRefresh
//
//  Created by huangzhibiao on 16/4/18.
//  Copyright © 2016年 JDRefresh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

