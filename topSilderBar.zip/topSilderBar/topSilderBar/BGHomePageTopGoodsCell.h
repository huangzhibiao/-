//
//  BGHomePageTopGoodsCell.h
//  topSilderBar
//
//  Created by huangzhibiao on 16/7/7.
//  Copyright © 2016年 Biao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BGHomePageTopGoodsCell : UICollectionViewCell

@end
