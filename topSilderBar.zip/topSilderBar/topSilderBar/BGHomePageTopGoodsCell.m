//
//  BGHomePageTopGoodsCell.m
//  topSilderBar
//
//  Created by huangzhibiao on 16/7/7.
//  Copyright © 2016年 Biao. All rights reserved.
//

#import "BGHomePageTopGoodsCell.h"

@implementation BGHomePageTopGoodsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
