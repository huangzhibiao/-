//
//  BuyBottomView.m
//  testLogin
//
//  Created by huangzhibiao on 15/12/21.
//  Copyright © 2015年 haiwang. All rights reserved.
//

#import "BuyBottomView.h"

@implementation BuyBottomView

+ (instancetype)view
{
    return [[[NSBundle mainBundle] loadNibNamed:@"BuyBottomView" owner:nil options:nil] firstObject];
}

@end
