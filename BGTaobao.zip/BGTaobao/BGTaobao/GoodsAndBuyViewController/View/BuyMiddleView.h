//
//  BuyMiddleView.h
//  testLogin
//
//  Created by huangzhibiao on 15/12/21.
//  Copyright © 2015年 haiwang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuyMiddleView : UIView

+ (instancetype)view;

@end
