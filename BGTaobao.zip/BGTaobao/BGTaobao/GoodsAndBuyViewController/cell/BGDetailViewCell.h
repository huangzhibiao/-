//
//  BGDetailViewCell.h
//  BGTaobao
//
//  Created by huangzhibiao on 16/2/19.
//  Copyright © 2016年 haiwang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BGDetailViewCell : UICollectionViewCell

@property(nonatomic,copy)NSString* image;

@end
